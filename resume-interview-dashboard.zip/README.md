# ResumeInsights — React Dashboard

A responsive React dashboard for exploring resume skills and interview-call outcomes. It includes filters, KPI cards, charts, a candidate table, CSV upload, and filtered CSV export.

## Run locally

1. Install Node.js (LTS).
2. Extract this project and open a terminal in the folder.
3. Run:

   ```bash
   npm install
   npm run dev
   ```

4. Open the local URL printed by Vite (usually `http://localhost:5173`).

## Load the Kaggle dataset

Download the CSV file from the Kaggle dataset page you shared. In the dashboard, click **Upload dataset** and select the CSV.

The dashboard attempts to identify columns by common header names:
- Skills: `skills`, `skill`, `skill_set`, `technical_skills`, `resume_skills`
- Interview outcome: `interview_call`, `call_status`, `called`, `callback`, `status`, etc.
- Role: `job_role`, `role`, `job_title`, `position`, `category`
- Experience: `experience`, `years_experience`, `work_experience`
- Education: `education`, `education_level`, `qualification`

If your dataset uses different column names, update the `pickKey()` term lists in `src/Dashboard.jsx`. The skill column should contain comma-, semicolon-, or pipe-separated skills. If the call outcome column uses different values, update `truthy()`.

## Important

The dashboard starts with clearly labeled **demo sample data** so you can preview the layout before uploading the Kaggle CSV. Demo values are illustrative, not findings from the dataset. Skill-call associations are descriptive and do not establish causation.

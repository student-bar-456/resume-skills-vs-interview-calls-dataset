import React, { useMemo, useRef, useState } from "react";
import Papa from "papaparse";
import {
  ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  PieChart, Pie, Cell, LineChart, Line, Legend
} from "recharts";
import { Upload, FileSpreadsheet, Users, PhoneCall, TrendingUp, BriefcaseBusiness, Search, Download, Sparkles, ChevronDown, FileUp, CheckCircle2 } from "lucide-react";

const demo = [
  {candidate_id:"C-1001",skills:"Python, SQL, Excel, Power BI",experience:2,education:"Bachelors",interview_call:"Yes",role:"Data Analyst"},
  {candidate_id:"C-1002",skills:"Java, SQL, React",experience:1,education:"Bachelors",interview_call:"No",role:"Software Developer"},
  {candidate_id:"C-1003",skills:"Python, Machine Learning, SQL",experience:3,education:"Masters",interview_call:"Yes",role:"Data Scientist"},
  {candidate_id:"C-1004",skills:"Excel, Power BI, Tableau",experience:2,education:"Bachelors",interview_call:"Yes",role:"Data Analyst"},
  {candidate_id:"C-1005",skills:"HTML, CSS, JavaScript, React",experience:1,education:"Bachelors",interview_call:"No",role:"Frontend Developer"},
  {candidate_id:"C-1006",skills:"Python, SQL, Tableau",experience:4,education:"Masters",interview_call:"Yes",role:"Business Analyst"},
  {candidate_id:"C-1007",skills:"Java, Spring, SQL",experience:5,education:"Bachelors",interview_call:"No",role:"Backend Developer"},
  {candidate_id:"C-1008",skills:"Excel, SQL, Power BI, Communication",experience:3,education:"Bachelors",interview_call:"Yes",role:"Data Analyst"},
  {candidate_id:"C-1009",skills:"Python, Statistics, Machine Learning",experience:2,education:"Masters",interview_call:"Yes",role:"Data Scientist"},
  {candidate_id:"C-1010",skills:"C++, DSA, Java",experience:1,education:"Bachelors",interview_call:"No",role:"Software Developer"},
  {candidate_id:"C-1011",skills:"SQL, Excel, Tableau",experience:2,education:"Bachelors",interview_call:"Yes",role:"Business Analyst"},
  {candidate_id:"C-1012",skills:"JavaScript, React, Node.js",experience:3,education:"Bachelors",interview_call:"No",role:"Frontend Developer"},
  {candidate_id:"C-1013",skills:"Python, SQL, Excel",experience:1,education:"Bachelors",interview_call:"Yes",role:"Data Analyst"},
  {candidate_id:"C-1014",skills:"Machine Learning, Python, TensorFlow",experience:4,education:"Masters",interview_call:"Yes",role:"Data Scientist"},
  {candidate_id:"C-1015",skills:"Excel, Communication, SQL",experience:0,education:"Bachelors",interview_call:"No",role:"Business Analyst"},
  {candidate_id:"C-1016",skills:"HTML, CSS, JavaScript",experience:2,education:"Diploma",interview_call:"No",role:"Frontend Developer"},
  {candidate_id:"C-1017",skills:"Python, Power BI, SQL",experience:3,education:"Bachelors",interview_call:"Yes",role:"Data Analyst"},
  {candidate_id:"C-1018",skills:"Java, SQL, AWS",experience:5,education:"Masters",interview_call:"Yes",role:"Backend Developer"},
  {candidate_id:"C-1019",skills:"Excel, Power BI, SQL",experience:1,education:"Bachelors",interview_call:"Yes",role:"Data Analyst"},
  {candidate_id:"C-1020",skills:"Python, Statistics, SQL",experience:2,education:"Masters",interview_call:"No",role:"Data Scientist"}
];

const COLORS=["#6558e8","#28a78b","#f2a94a","#ef7188","#5a9ee6","#9a75d5","#4cb5c1"];
const norm = v => String(v ?? "").trim().toLowerCase().replace(/[^a-z0-9]+/g,"_").replace(/^_|_$/g,"");
function pickKey(keys, terms) {
  return keys.find(k => terms.some(t => norm(k) === t)) || keys.find(k => terms.some(t => norm(k).includes(t)));
}
function truthy(v) {
  const s=String(v??"").trim().toLowerCase();
  if(["yes","y","true","1","called","selected","received","shortlisted"].includes(s)) return true;
  if(["no","n","false","0","not called","rejected","not selected"].includes(s)) return false;
  return null;
}
function getCallKey(keys){return pickKey(keys,["interview_call","interview_calls","interview","call_status","call_received","interview_invitation","called","callback","response","status","selected"]);}
function parseRows(raw) {
  if(!raw?.length) return [];
  const keys=Object.keys(raw[0]||{});
  const skillsKey=pickKey(keys,["skills","skill","skill_set","technical_skills","resume_skills","skillset"]);
  const callKey=getCallKey(keys);
  const roleKey=pickKey(keys,["job_role","role","job_title","position","category","profile"]);
  const expKey=pickKey(keys,["experience","years_experience","work_experience","experience_years"]);
  const eduKey=pickKey(keys,["education","education_level","qualification","degree"]);
  const idKey=pickKey(keys,["candidate_id","resume_id","id","applicant_id"]);
  return raw.filter(r=>r && Object.values(r).some(v=>String(v??"").trim())).map((r,i)=>({
    ...r,
    __id:String(r[idKey]??`Candidate ${i+1}`),
    __skills:String(r[skillsKey]??"").split(/[,;|]/).map(s=>s.trim()).filter(Boolean),
    __call:callKey?truthy(r[callKey]):null,
    __role:String(r[roleKey]??"Not specified").trim()||"Not specified",
    __exp:Number(r[expKey])||0,
    __edu:String(r[eduKey]??"Not specified").trim()||"Not specified"
  }));
}
const money = n => new Intl.NumberFormat("en-IN").format(n);
function ChartCard({title,subtitle,children,wide=false}) {
  return <section className={`panel chart-panel ${wide?"wide":""}`}><div className="panel-heading"><div><h3>{title}</h3><p>{subtitle}</p></div><button className="dots" aria-label="Chart options">•••</button></div>{children}</section>;
}
function Dashboard(){
  const [rows,setRows]=useState(()=>parseRows(demo));
  const [isDemo,setIsDemo]=useState(true);
  const [search,setSearch]=useState("");
  const [role,setRole]=useState("All roles");
  const [callFilter,setCallFilter]=useState("All outcomes");
  const [fileName,setFileName]=useState("");
  const inputRef=useRef(null);
  const filtered=useMemo(()=>rows.filter(r=>
    (role==="All roles"||r.__role===role) &&
    (callFilter==="All outcomes"||(callFilter==="Called"&&r.__call===true)||(callFilter==="Not called"&&r.__call===false)) &&
    (!search||[r.__id,r.__role,...r.__skills].join(" ").toLowerCase().includes(search.toLowerCase()))
  ),[rows,role,callFilter,search]);
  const called=filtered.filter(r=>r.__call===true).length;
  const known=filtered.filter(r=>r.__call!==null).length;
  const rate=known?Math.round(called/known*100):0;
  const skillStats=useMemo(()=>{
    const map={};
    filtered.forEach(r=>[...new Set(r.__skills)].forEach(s=>{
      if(!map[s])map[s]={skill:s,total:0,calls:0};
      map[s].total++; if(r.__call===true)map[s].calls++;
    }));
    return Object.values(map).map(x=>({...x,rate:x.total?Math.round(x.calls/x.total*100):0})).sort((a,b)=>b.total-a.total).slice(0,8);
  },[filtered]);
  const roleStats=useMemo(()=>{
    const map={};
    filtered.forEach(r=>{if(!map[r.__role])map[r.__role]={role:r.__role,total:0,calls:0,known:0};const x=map[r.__role];x.total++;if(r.__call!==null){x.known++;if(r.__call)x.calls++;}});
    return Object.values(map).map(x=>({...x,rate:x.known?Math.round(x.calls/x.known*100):0})).sort((a,b)=>b.total-a.total).slice(0,6);
  },[filtered]);
  const outcome=[{name:"Interview call",value:called},{name:"No call",value:filtered.filter(r=>r.__call===false).length},{name:"Unknown",value:filtered.filter(r=>r.__call===null).length}];
  const expStats=useMemo(()=>{const groups={"0–1 yrs":{name:"0–1 yrs",calls:0,total:0},"2–3 yrs":{name:"2–3 yrs",calls:0,total:0},"4–5 yrs":{name:"4–5 yrs",calls:0,total:0},"6+ yrs":{name:"6+ yrs",calls:0,total:0}};filtered.forEach(r=>{const k=r.__exp<=1?"0–1 yrs":r.__exp<=3?"2–3 yrs":r.__exp<=5?"4–5 yrs":"6+ yrs";groups[k].total++;if(r.__call===true)groups[k].calls++;});return Object.values(groups).map(x=>({...x,rate:x.total?Math.round(x.calls/x.total*100):0}));},[filtered]);
  const roles=["All roles",...new Set(rows.map(r=>r.__role))];
  function upload(file){
    if(!file)return;
    Papa.parse(file,{header:true,skipEmptyLines:true,complete:res=>{
      const parsed=parseRows(res.data);
      if(parsed.length){setRows(parsed);setIsDemo(false);setFileName(file.name);setRole("All roles");setCallFilter("All outcomes");}
      else alert("Could not read rows from this CSV. Please check the file headers and contents.");
    },error:()=>alert("Unable to read this file. Please upload a valid CSV.")});
  }
  function exportCsv(){
    const data=filtered.map(r=>({candidate:r.__id,role:r.__role,skills:r.__skills.join(", "),experience_years:r.__exp,education:r.__edu,interview_call:r.__call===true?"Yes":r.__call===false?"No":"Unknown"}));
    const csv=Papa.unparse(data);const url=URL.createObjectURL(new Blob([csv],{type:"text/csv;charset=utf-8;"}));const a=document.createElement("a");a.href=url;a.download="resume-insights-filtered.csv";a.click();URL.revokeObjectURL(url);
  }
  return <div className="app-shell">
    <aside className="sidebar">
      <div className="brand"><div className="brand-mark"><Sparkles size={21}/></div><div><b>Resume<span>Insights</span></b><small>RECRUITMENT ANALYTICS</small></div></div>
      <div className="side-label">WORKSPACE</div>
      <div className="nav-item active"><span className="nav-icon">▦</span> Overview</div>
      <div className="nav-item"><span className="nav-icon">▤</span> Skills analysis</div>
      <div className="nav-item"><span className="nav-icon">◉</span> Interview outcomes</div>
      <div className="nav-item"><span className="nav-icon">♙</span> Candidate insights</div>
      <div className="sidebar-bottom"><div className="help-card"><div className="help-icon"><FileSpreadsheet size={19}/></div><b>Bring your own data</b><p>Upload your dataset to explore real interview trends.</p><button onClick={()=>inputRef.current?.click()}>Upload CSV <Upload size={14}/></button></div><div className="profile"><div className="avatar">RI</div><div><b>Recruitment Team</b><small>Analytics workspace</small></div><ChevronDown size={16}/></div></div>
    </aside>
    <main className="main">
      <header className="topbar"><div className="breadcrumb">Workspace <span>/</span> <b>Overview</b></div><div className="top-actions"><span className="live-dot"></span><span className="updated">Dashboard overview</span><button className="export-btn" onClick={exportCsv}><Download size={16}/> Export CSV</button></div></header>
      <div className="content">
        <div className="page-heading"><div><div className="eyebrow">RECRUITMENT PERFORMANCE</div><h1>Resume & Interview Insights <span className="wave">✳</span></h1><p>Understand how candidate skills connect with interview call outcomes.</p></div><button className="upload-btn" onClick={()=>inputRef.current?.click()}><Upload size={17}/> Upload dataset</button><input ref={inputRef} type="file" accept=".csv,text/csv" hidden onChange={e=>{upload(e.target.files?.[0]);e.target.value="";}}/></div>
        <div className="dataset-note"><span className="file-badge"><FileSpreadsheet size={17}/></span><div><b>{isDemo?"Demo dataset":fileName||"Uploaded dataset"}</b><small>{isDemo?"Sample data for preview · Upload your Kaggle CSV to see your own results":`${money(rows.length)} candidate records loaded`}</small></div><span className="data-status"><CheckCircle2 size={15}/>{isDemo?"Preview":"Loaded"}</span></div>
        <div className="filters"><div className="search-box"><Search size={17}/><input placeholder="Search skills, roles or candidates..." value={search} onChange={e=>setSearch(e.target.value)}/></div><label className="filter-select"><span>Role</span><select value={role} onChange={e=>setRole(e.target.value)}>{roles.map(x=><option key={x}>{x}</option>)}</select></label><label className="filter-select"><span>Outcome</span><select value={callFilter} onChange={e=>setCallFilter(e.target.value)}>{["All outcomes","Called","Not called"].map(x=><option key={x}>{x}</option>)}</select></label><button className="clear-btn" onClick={()=>{setSearch("");setRole("All roles");setCallFilter("All outcomes");}}>Reset</button></div>
        <div className="section-title"><h2>At a glance</h2><span>Based on {money(filtered.length)} filtered records</span></div>
        <div className="kpi-grid">
          <div className="kpi-card"><div className="kpi-top"><span>Total candidates</span><span className="kpi-icon purple"><Users size={19}/></span></div><strong>{money(filtered.length)}</strong><div className="kpi-foot"><span className="foot-dot purple-dot"></span>Candidate profiles analyzed</div></div>
          <div className="kpi-card"><div className="kpi-top"><span>Interview calls</span><span className="kpi-icon green"><PhoneCall size={19}/></span></div><strong>{money(called)}</strong><div className="kpi-foot"><span className="foot-dot green-dot"></span>Confirmed call records</div></div>
          <div className="kpi-card"><div className="kpi-top"><span>Interview call rate</span><span className="kpi-icon orange"><TrendingUp size={19}/></span></div><strong>{known?rate+"%":"—"}</strong><div className="kpi-foot"><span className="foot-dot orange-dot"></span>{known?`${called} of ${known} known outcomes`:"Outcome column not detected"}</div></div>
          <div className="kpi-card"><div className="kpi-top"><span>Unique skills</span><span className="kpi-icon pink"><BriefcaseBusiness size={19}/></span></div><strong>{new Set(filtered.flatMap(r=>r.__skills)).size}</strong><div className="kpi-foot"><span className="foot-dot pink-dot"></span>Skills found in resumes</div></div>
        </div>
        <div className="charts-grid">
          <ChartCard title="Skills & interview call rate" subtitle="Most frequently listed skills and their call rate" wide>
            {skillStats.length?<ResponsiveContainer width="100%" height={270}><BarChart data={skillStats} margin={{top:10,right:10,left:-18,bottom:4}} barGap={6}><CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#edf0f6"/><XAxis dataKey="skill" tick={{fontSize:11,fill:"#7d8498"}} axisLine={false} tickLine={false}/><YAxis tick={{fontSize:11,fill:"#7d8498"}} axisLine={false} tickLine={false}/><Tooltip cursor={{fill:"#f6f5ff"}} contentStyle={{border:"1px solid #edf0f6",borderRadius:12,fontSize:12}}/><Legend wrapperStyle={{fontSize:12,paddingTop:10}}/><Bar dataKey="total" name="Candidates with skill" fill="#d9d5ff" radius={[5,5,0,0]} maxBarSize={34}/><Bar dataKey="calls" name="Interview calls" fill="#6558e8" radius={[5,5,0,0]} maxBarSize={34}/></BarChart></ResponsiveContainer>:<Empty/>}
          </ChartCard>
          <ChartCard title="Interview outcomes" subtitle="Distribution across filtered candidates">
            <div className="donut-wrap">{known||outcome[2]?<ResponsiveContainer width="100%" height={205}><PieChart><Pie data={outcome} dataKey="value" nameKey="name" innerRadius={57} outerRadius={83} paddingAngle={4} stroke="none">{outcome.map((e,i)=><Cell key={e.name} fill={["#6558e8","#e8e9f2","#f2a94a"][i]}/>)}</Pie><Tooltip/></PieChart></ResponsiveContainer>:<Empty/>}<div className="donut-center"><strong>{known?rate+"%":"—"}</strong><span>Call rate</span></div></div>
            <div className="legend-list">{outcome.map((x,i)=><div key={x.name}><span className="legend-name"><i style={{background:["#6558e8","#e8e9f2","#f2a94a"][i]}}/>{x.name}</span><b>{x.value}</b></div>)}</div>
          </ChartCard>
          <ChartCard title="Interview calls by job role" subtitle="Candidate volume and confirmed call rate" wide>
            {roleStats.length?<ResponsiveContainer width="100%" height={255}><BarChart data={roleStats} margin={{top:10,right:12,left:-18,bottom:3}}><CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#edf0f6"/><XAxis dataKey="role" tick={{fontSize:11,fill:"#7d8498"}} axisLine={false} tickLine={false}/><YAxis tick={{fontSize:11,fill:"#7d8498"}} axisLine={false} tickLine={false}/><Tooltip contentStyle={{borderRadius:12,fontSize:12}}/><Legend wrapperStyle={{fontSize:12}}/><Bar dataKey="total" name="Candidates" fill="#d9d5ff" radius={[5,5,0,0]} maxBarSize={38}/><Bar dataKey="calls" name="Interview calls" fill="#28a78b" radius={[5,5,0,0]} maxBarSize={38}/></BarChart></ResponsiveContainer>:<Empty/>}
          </ChartCard>
          <ChartCard title="Call rate by experience" subtitle="Interview call rate across experience bands">
            <ResponsiveContainer width="100%" height={255}><LineChart data={expStats} margin={{top:15,right:8,left:-18,bottom:4}}><CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#edf0f6"/><XAxis dataKey="name" tick={{fontSize:11,fill:"#7d8498"}} axisLine={false} tickLine={false}/><YAxis domain={[0,100]} unit="%" tick={{fontSize:11,fill:"#7d8498"}} axisLine={false} tickLine={false}/><Tooltip formatter={(v,n)=>[n==="rate"?`${v}%`:v,n==="rate"?"Call rate":n]}/><Line type="monotone" dataKey="rate" name="Call rate" stroke="#6558e8" strokeWidth={3} dot={{r:5,fill:"#6558e8",strokeWidth:2,stroke:"#fff"}}/></LineChart></ResponsiveContainer>
          </ChartCard>
        </div>
        <section className="panel table-panel"><div className="panel-heading"><div><h3>Candidate records</h3><p>Browse the candidates included in your current filters</p></div><span className="table-count">{filtered.length} records</span></div><div className="table-scroll"><table><thead><tr><th>Candidate</th><th>Job role</th><th>Skills</th><th>Experience</th><th>Education</th><th>Interview outcome</th></tr></thead><tbody>{filtered.slice(0,10).map((r,i)=><tr key={r.__id+i}><td><div className="candidate-cell"><span className="mini-avatar">{String(r.__id).replace(/[^a-z0-9]/gi,"").slice(-2).toUpperCase()||"C"}</span><b>{r.__id}</b></div></td><td>{r.__role}</td><td><div className="skill-pills">{r.__skills.slice(0,3).map(s=><span key={s}>{s}</span>)}{r.__skills.length>3&&<small>+{r.__skills.length-3}</small>}</div></td><td>{r.__exp} yrs</td><td>{r.__edu}</td><td><span className={`status ${r.__call===true?"yes":r.__call===false?"no":"unknown"}`}><i/>{r.__call===true?"Interview call":r.__call===false?"No call":"Unknown"}</span></td></tr>)}</tbody></table>{!filtered.length&&<div className="empty-table">No records match your filters.</div>}</div>{filtered.length>10&&<div className="table-footer">Showing 10 of {filtered.length} records. Export CSV to download all filtered rows.</div>}</section>
        <footer>ResumeInsights <span>·</span> Skill patterns are descriptive and do not imply that a skill causes an interview call.</footer>
      </div>
    </main>
  </div>;
}
function Empty(){return <div className="empty-chart">No data available for this chart.</div>}
export default Dashboard;

# GradPay — Engineering Fresher Salary Dashboard

Responsive React + Vite dashboard with salary KPIs, role/city/specialization/college-tier charts, filters, candidate table, CSV upload and filtered CSV export.

## Run locally (Windows)
1. Install Node.js LTS from https://nodejs.org/en/download/
2. Extract the ZIP and open this project folder in VS Code.
3. Terminal → New Terminal, then run `npm install`
4. Run `npm run dev`
5. Open the localhost URL Vite prints (usually http://localhost:5173).

## Use the Kaggle data
Download the dataset CSV and click **Upload dataset** in the dashboard. Column matching recognizes common names for salary, designation, city, gender, college tier, specialization, and ID. Adjust the `keys` lists in `src/Dashboard.jsx` if your headers differ.

The initial preview uses illustrative demo records, not actual Kaggle findings. Salary is assumed to be annual INR; verify the dataset's units before interpreting results.
